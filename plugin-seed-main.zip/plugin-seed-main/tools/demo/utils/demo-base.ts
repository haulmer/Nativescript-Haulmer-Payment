import { Observable } from '@nativescript/core';

export class DemoSharedBase extends Observable {
	// in case you want to globally control how your shared demo code works across whole workspace
}
