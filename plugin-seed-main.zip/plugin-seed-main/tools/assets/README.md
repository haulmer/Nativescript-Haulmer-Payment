Assets shared across multiple targets in the workspace to reduce filesize of the repo as well as reduce maintenance costs of duplicate assets.

* `App_Resources`: All `e2e` app harnesses share the same App_Resources from here.